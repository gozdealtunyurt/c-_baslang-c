﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S6.D3.SortedListGenelYapisi
{
    class Program
    {
        static void Main(string[] args)
        {
          
        }
    }
}
