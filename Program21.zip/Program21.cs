﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S4.D4.DoWhileDongusu
{
    class Program
    {
        static void Main(string[] args)
        {
            //while(true)
            //{
            //    // kodlarımız çalış
            //}

            do
            {

                Console.WriteLine("Merhaba Do While şşşçççİİİİ");
            } while (1 == 2);

            // do while döngülerindeki en temel fark şartları ne olursa olsun 1 kere kesin çalışır. 
        }
    }
}
